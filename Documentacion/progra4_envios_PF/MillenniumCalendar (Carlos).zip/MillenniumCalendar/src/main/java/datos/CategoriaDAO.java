package datos;

import dominios.Categoria;
import java.sql.*;
import java.util.*;

public class CategoriaDAO {
    
    /* Metodo para listar */
    public List<Categoria> Listar() {
        /* Importamos todo lo que vamos a utilizar */
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Categoria categoria = null;
        
        /* Definimos una lista que almacenara todos los datos */
        /* Y lo inicializamos */
        List<Categoria> categorias = new ArrayList<>();
        
        try
        {
            /* Obetenmos la conexion */
            conn = Conexion.getConnection();

            /* Inicializamos la consulta */
            stmt = conn.prepareCall("{call SP_listar_categorias()}");

            /* Ejecutamos el Query y lo asignamos a una variable */
            rs = stmt.executeQuery();
            
            /* Iteramos los registros que recuperemos */
            /* Usamos el .next para pocisionarnos en el primer registro que itera */
            /* automaticamente mientras encuentra aregistros */
            while (rs.next())
            {
                int idCategoria = rs.getInt("id_categoria");
                String nombreCategoria = rs.getString("nombre_categoria");
                String descripcion = rs.getString("descripcion");
                String estadoCategoria = rs.getString("estado_categoria");
                
                /* Creamos un nuevo objeto y asignamos a la variable de categorias */
                categoria = new Categoria(idCategoria, nombreCategoria, descripcion, estadoCategoria);
            
                /* Agregamos el objeto a la lista de categorias */
                categorias.add(categoria);
            }
            
        } catch (SQLException e)
        {
            e.printStackTrace(System.out);
        } finally {
            /* Se cierran en el orden inverso que se abrieron */
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        
        return categorias;
    }
}
