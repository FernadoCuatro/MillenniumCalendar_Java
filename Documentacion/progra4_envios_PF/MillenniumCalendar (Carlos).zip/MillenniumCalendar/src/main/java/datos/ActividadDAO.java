package datos;

import dominios.Actividad;
import java.sql.*;
import java.util.*;

public class ActividadDAO {

    public List<Actividad> Listar() {

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Actividad actividad = null;

        List<Actividad> Actividades = new ArrayList<>();

        try {
            conn = Conexion.getConnection();

            stmt = conn.prepareCall("{call SP_listar_actividad()}");

            rs = stmt.executeQuery();

            while (rs.next()) {
                String nombreCategoria = rs.getString("nombre_categoria");
                String nombreFacilitador = rs.getString("nombre_facilitador");
                String nombreActividad = rs.getString("nombre_actividad");
                String fechaInicio = rs.getString("fecha_inicio");
                String fechaFinal = rs.getString("fecha_final");
                String diasSemana = rs.getString("dias_semana");
                String horasDias = rs.getString("horas_dias");
                String descripcion = rs.getString("descripcion");

                actividad = new Actividad(nombreActividad, fechaInicio, fechaFinal, diasSemana, horasDias, descripcion, nombreCategoria, nombreFacilitador);

                Actividades.add(actividad);
            }

        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } finally {

            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return Actividades;
    }

    public List<Actividad> ListarDetalles() {

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Actividad actividad = null;

        List<Actividad> Actividades = new ArrayList<>();

        try {
            conn = Conexion.getConnection();

            stmt = conn.prepareCall("{call SP_listar_actividad_detalles()}");

            rs = stmt.executeQuery();

            while (rs.next()) {
                String nombreCategoria = rs.getString("nombre_categoria");
                String nombreFacilitador = rs.getString("nombre_facilitador");
                int idActividad = rs.getInt("id_actividad");
                int idCategoria = rs.getInt("id_categoria");
                int idFacilitador = rs.getInt("id_facilitador");
                String nombreActividad = rs.getString("nombre_actividad");
                String fechaInicio = rs.getString("fecha_inicio");
                String fechaFinal = rs.getString("fecha_final");
                String diasSemana = rs.getString("dias_semana");
                String horasDias = rs.getString("horas_dias");
                String descripcion = rs.getString("descripcion");
                String estadoActividad = rs.getString("estado_actividad");

                actividad = new Actividad(idActividad, idCategoria, idFacilitador, nombreActividad, fechaInicio, fechaFinal, diasSemana, horasDias, descripcion, estadoActividad, nombreCategoria, nombreFacilitador);

                Actividades.add(actividad);
            }

        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } finally {

            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return Actividades;
    }

    public int insertar(Actividad actividad) {

        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;

        try {
            conn = Conexion.getConnection();

            stmt = conn.prepareStatement("{call SP_agregar_actividad(?,?,?,?,?,?,?,?,?)}");
            stmt.setInt(1, actividad.getIdCategoria());
            stmt.setInt(2, actividad.getIdFacilitador());
            stmt.setString(3, actividad.getNombreActividad());
            stmt.setString(4, actividad.getFechaInicio());
            stmt.setString(5, actividad.getFechaFinal());
            stmt.setString(6, actividad.getDiasSemana());
            stmt.setString(7, actividad.getHorasDias());
            stmt.setString(8, actividad.getDescripcion());
            stmt.setString(9, actividad.getEstadoActividad());

            rows = stmt.executeUpdate();
        } catch (SQLException e) {
            
            e.printStackTrace(System.out);
        } finally {

            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return rows;
    }

    public Actividad encontrar(Actividad actividad) {

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement("{call SP_buscar_actividad(?)}");
            stmt.setInt(1, actividad.getIdActividad());

            rs = stmt.executeQuery();

            while (rs.next()) {
                int idActividad = rs.getInt("id_actividad");
                int idCategoria = rs.getInt("id_categoria");
                int idFacilitador = rs.getInt("id_facilitador");
                String nombreActividad = rs.getString("nombre_actividad");
                String fechaInicio = rs.getString("fecha_inicio");
                String fechaFinal = rs.getString("fecha_final");
                String diasSemana = rs.getString("dias_semana");
                String horasDias = rs.getString("horas_dias");
                String descripcion = rs.getString("descripcion");
                String estadoActividad = rs.getString("estado_actividad");

                actividad = new Actividad(idActividad, idCategoria, idFacilitador, nombreActividad, fechaInicio, fechaFinal, diasSemana, horasDias, descripcion, estadoActividad);
            }

        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return actividad;
    }

    public Actividad detalles(Actividad actividad) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement("{call SP_buscar_actividad_detalles(?)}");
            stmt.setInt(1, actividad.getIdActividad());

            rs = stmt.executeQuery();

            while (rs.next()) {
                String nombreCategoria = rs.getString("nombre_categoria");
                String nombreFacilitador = rs.getString("nombre_facilitador");
                int idActividad = rs.getInt("id_actividad");
                int idCategoria = rs.getInt("id_categoria");
                int idFacilitador = rs.getInt("id_facilitador");
                String nombreActividad = rs.getString("nombre_actividad");
                String fechaInicio = rs.getString("fecha_inicio");
                String fechaFinal = rs.getString("fecha_final");
                String diasSemana = rs.getString("dias_semana");
                String horasDias = rs.getString("horas_dias");
                String descripcion = rs.getString("descripcion");
                String estadoActividad = rs.getString("estado_actividad");

                actividad = new Actividad(idActividad, idCategoria, idFacilitador, nombreActividad, fechaInicio, fechaFinal, diasSemana, horasDias, descripcion, estadoActividad, nombreCategoria, nombreFacilitador);
            }

        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return actividad;
    }

    public int actualizar(Actividad actividad) {

        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;

        try {
            conn = Conexion.getConnection();

            stmt = conn.prepareStatement("{call SP_actualizar_actividad(?,?,?,?,?,?,?,?,?,?)}");
            stmt.setInt(1, actividad.getIdActividad());
            stmt.setInt(2, actividad.getIdCategoria());
            stmt.setInt(3, actividad.getIdFacilitador());
            stmt.setString(4, actividad.getNombreActividad());
            stmt.setString(5, actividad.getFechaInicio());
            stmt.setString(6, actividad.getFechaFinal());
            stmt.setString(7, actividad.getDiasSemana());
            stmt.setString(8, actividad.getHorasDias());
            stmt.setString(9, actividad.getDescripcion());
            stmt.setString(10, actividad.getEstadoActividad());

            rows = stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return rows;
    }

    public int eliminar(Actividad actividad) {

        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;

        try {
            conn = Conexion.getConnection();

            stmt = conn.prepareStatement("{call SP_eliminar_actividad(?)}");
            stmt.setInt(1, actividad.getIdActividad());

            rows = stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return rows;
    }

}
