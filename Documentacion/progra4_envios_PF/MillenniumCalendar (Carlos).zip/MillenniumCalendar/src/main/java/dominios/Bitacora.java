package dominios;

public class Bitacora {
    
    private int idRegistro;
    private int idAdministrador;
    private String tipoRegistro;
    private String fechaRegistro;
    private String descripcionRegistro;
    
    public Bitacora() {
    }
    
    public Bitacora(int idAdministrador, String tipoRegistro, String descripcionRegistro) {
        this.idAdministrador = idAdministrador;
        this.tipoRegistro = tipoRegistro;
        this.descripcionRegistro = descripcionRegistro;
    }
    
    public Bitacora(int idRegistro, int idAdministrador, String tipoRegistro, String fechaRegistro, String descripcionRegistro) {
        this.idRegistro = idRegistro;
        this.idAdministrador = idAdministrador;
        this.tipoRegistro = tipoRegistro;
        this.fechaRegistro = fechaRegistro;
        this.descripcionRegistro = descripcionRegistro;
    }
    
    public int getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(int idRegistro) {
        this.idRegistro = idRegistro;
    }

    public int getIdAdministrador() {
        return idAdministrador;
    }

    public void setIdAdministrador(int idAdministrador) {
        this.idAdministrador = idAdministrador;
    }

    public String getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(String tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getDescripcionRegistro() {
        return descripcionRegistro;
    }

    public void setDescripcionRegistro(String descripcionRegistro) {
        this.descripcionRegistro = descripcionRegistro;
    }   
}
