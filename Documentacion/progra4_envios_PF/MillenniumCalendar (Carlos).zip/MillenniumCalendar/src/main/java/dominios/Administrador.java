package dominios;

import util.Hash;

public class Administrador {

    private int idAdministrador;
    private String nombreAdministrador;
    private String apellidoAdministrador;
    private String estadoAdministrador;

    private int idLogin;
    private String correoLogin;
    private String claveLogin;
    private String estadoLogin;
    
    public Administrador() {
    }
    
    public Administrador(int idAdministrador) {
        this.idAdministrador = idAdministrador;
    }

    
    public Administrador(String nombreAdministrador, String apellidoAdministrador, String estadoAdministrador) {
        this.nombreAdministrador = nombreAdministrador;
        this.apellidoAdministrador = apellidoAdministrador;
        this.estadoAdministrador = estadoAdministrador;
    }

    public Administrador(int idAdministrador, String nombreAdministrador, String apellidoAdministrador, String correoLogin) {
        this.idAdministrador = idAdministrador;
        this.nombreAdministrador = nombreAdministrador;
        this.apellidoAdministrador = apellidoAdministrador;
        this.correoLogin = correoLogin;
    }
    
    public Administrador(int idAdministrador, String nombreAdministrador, String apellidoAdministrador, String estadoAdministrador, String correoLogin, String estadoLogin) {
        this.idAdministrador = idAdministrador;
        this.nombreAdministrador = nombreAdministrador;
        this.apellidoAdministrador = apellidoAdministrador;
        this.estadoAdministrador = estadoAdministrador;
        this.correoLogin = correoLogin;
        this.estadoLogin = estadoLogin;
    }
    
    public int getIdAdministrador() {
        return idAdministrador;
    }

    public void setIdAdministrador(int idAdministrador) {
        this.idAdministrador = idAdministrador;
    }

    public String getNombreAdministrador() {
        return nombreAdministrador;
    }

    public void setNombreAdministrador(String nombreAdministrador) {
        this.nombreAdministrador = nombreAdministrador;
    }

    public String getApellidoAdministrador() {
        return apellidoAdministrador;
    }

    public void setApellidoAdministrador(String apellidoAdministrador) {
        this.apellidoAdministrador = apellidoAdministrador;
    }

    public String getEstadoAdministrador() {
        return estadoAdministrador;
    }

    public void setEstadoAdministrador(String estadoAdministrador) {
        this.estadoAdministrador = estadoAdministrador;
    }

    public int getIdLogin() {
        return idLogin;
    }

    public void setIdLogin(int idLogin) {
        this.idLogin = idLogin;
    }

    public String getCorreoLogin() {
        return correoLogin;
    }

    public void setCorreoLogin(String correoLogin) {
        this.correoLogin = correoLogin;
    }

    public String getClaveLogin() {
        return claveLogin;
    }

    public void setClaveLogin(String claveLogin) {
        this.claveLogin = claveLogin;
    }

    public String getEstadoLogin() {
        return estadoLogin;
    }

    public void setEstadoLogin(String estadoLogin) {
        this.estadoLogin = estadoLogin;
    }  
}
