package dominios;

public class Categoria {

    private int idCategoria;
    private String nombreCategoria;
    private String descripcion;
    private String estadoCategoria;
    
    public Categoria() {
    }
    
    public Categoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }
    
    public Categoria(String nombreCategoria, String descripcion, String estadoCategoria) {
        this.nombreCategoria = nombreCategoria;
        this.descripcion = descripcion;
        this.estadoCategoria = estadoCategoria;
    }
    
    public Categoria(int idCategoria, String nombreCategoria, String descripcion, String estadoCategoria) {
        this.idCategoria = idCategoria;
        this.nombreCategoria = nombreCategoria;
        this.descripcion = descripcion;
        this.estadoCategoria = estadoCategoria;
    }
    
    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstadoCategoria() {
        return estadoCategoria;
    }

    public void setEstadoCategoria(String estadoCategoria) {
        this.estadoCategoria = estadoCategoria;
    }    
}
