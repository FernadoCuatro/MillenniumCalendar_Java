package web;

import datos.*;
import dominios.*;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/PublicoControlador")
public class PublicoControlador extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String pag = request.getParameter("pag");

        if (pag != null) {
            switch (pag) {
                case "1":
                    this.cargarActividades(request, response);
                    break;

                case "2":
                    this.cargarCategorias(request, response);
                    break;

                case "3":
                    this.cargarFacilitadores(request, response);
                    break;

                default:
                    this.cargarActividades(request, response);
            }
        } else {
            this.cargarActividades(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String login = request.getParameter("login");
        
        if (login != null) {
            
            switch (login) {
                
                case "iniciar":
                    this.login(request, response);
                    break;

                default:
                    this.cargarActividades(request, response);
            }
        }
    }

    private void cargarActividades(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Actividad> actividades = new ActividadDAO().Listar();

        HttpSession sesion = request.getSession();

        sesion.setAttribute("actividades", actividades);

        response.sendRedirect("calendario.jsp");
    }

    private void cargarCategorias(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Categoria> categorias = new CategoriaDAO().Listar();

        HttpSession sesion = request.getSession();

        sesion.setAttribute("categorias", categorias);

        response.sendRedirect("categorias.jsp");
    }

    private void cargarFacilitadores(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Facilitador> facilitadores = new FacilitadorDAO().Listar();

        HttpSession sesion = request.getSession();

        sesion.setAttribute("facilitadores", facilitadores);

        response.sendRedirect("facilitadores.jsp");
    }

    private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String correoLogin = request.getParameter("correo");
        String claveLogin = request.getParameter("pw");

        Administrador login = new AdministradorDAO().login(correoLogin, claveLogin);

        if (login != null && login.getIdAdministrador() != 0) {            
            
            HttpSession sesionLogin = request.getSession();

            sesionLogin.setAttribute("idAdministrador", login.getIdAdministrador());
            sesionLogin.setAttribute("nombreAdministrador", login.getNombreAdministrador());
            sesionLogin.setAttribute("apellidoAdministrador", login.getApellidoAdministrador());
            sesionLogin.setAttribute("correoLogin", login.getCorreoLogin());

            response.sendRedirect(request.getContextPath() + "/administracion/index.jsp");
        
        } else {
            
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        }
    }
}
