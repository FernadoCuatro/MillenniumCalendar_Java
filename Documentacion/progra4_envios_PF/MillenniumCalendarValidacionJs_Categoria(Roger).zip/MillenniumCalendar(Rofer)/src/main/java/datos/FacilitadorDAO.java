package datos;

import dominios.Facilitador;
import java.sql.*;
import java.util.*;

public class FacilitadorDAO {
    /* Metodo para listar */
    public List<Facilitador> Listar() {
        /* Importamos todo lo que vamos a utilizar */
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Facilitador facilitador = null;
        
        /* Definimos una lista que almacenara todos los datos */
        /* Y lo inicializamos */
        List<Facilitador> Facilitadores = new ArrayList<>();
        
        try
        {
            /* Obetenmos la conexion */
            conn = Conexion.getConnection();

            /* Inicializamos la consulta */
            stmt = conn.prepareCall("{call SP_listar_facilitador()}");

            /* Ejecutamos el Query y lo asignamos a una variable */
            rs = stmt.executeQuery();
            
            /* Iteramos los registros que recuperemos */
            /* Usamos el .next para pocisionarnos en el primer registro que itera */
            /* automaticamente mientras encuentra aregistros */
            while (rs.next())
            {   
                int idFacilitador = rs.getInt("id_facilitador");
                String nombreFaciitador = rs.getString("nombre_facilitador");
                String estudio = rs.getString("estudio");
                String estadoFacilitador = rs.getString("estado_facilitador");
                
                /* Creamos un nuevo objeto y asignamos el objeto de facilitadores */
                facilitador = new Facilitador(idFacilitador, nombreFaciitador, estudio, estadoFacilitador);
            
                /* Agregamos el objeto a la lista de facilitadores */
                Facilitadores.add(facilitador);
            }
            
        } catch (SQLException e)
        {
            e.printStackTrace(System.out);
        } finally {
            /* Se cierran en el orden inverso que se abrieron */
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        
        return Facilitadores;
    }
}
