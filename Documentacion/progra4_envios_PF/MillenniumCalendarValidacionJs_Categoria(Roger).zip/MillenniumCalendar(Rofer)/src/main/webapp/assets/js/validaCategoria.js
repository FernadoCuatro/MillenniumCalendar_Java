function validarNombreCategoria(texto, campos_alerta, alerta_nombre, longitud) {
    var desabilitar = document.getElementById("envio");
    
    if (texto.value.length < longitud) {
        document.getElementById(alerta_nombre).innerHTML = campos_alerta + " debe tener mas de " + longitud + " caracteres. Actualmente cuenta con: " + texto.value.length;
        desabilitar.disabled = true;
    } else {
        document.getElementById(alerta_nombre).innerHTML = "";
        desabilitar.disabled = false;
    }
}

function validarDescripcionCategoria(texto, campos_alerta, alerta_descrip, longitud) {
    var desabilitar = document.getElementById("envio");
    
    if (texto.value.length < longitud) {
        document.getElementById(alerta_descrip).innerHTML = campos_alerta + " debe tener mas de " + longitud + " caracteres. Actualmente cuenta con: " + texto.value.length;
        desabilitar.disabled = true;
    } else {
        document.getElementById(alerta_descrip).innerHTML = "";
        desabilitar.disabled = false;
    }
}

function validarNombreCategoriaEditar(texto, campos_alerta, alerta_nombreEditar, longitud) {
    var desabilitar = document.getElementById("envio");
    
    if (texto.value.length < longitud) {
        document.getElementById(alerta_nombreEditar).innerHTML = campos_alerta + " debe tener mas de " + longitud + " caracteres. Actualmente cuenta con: " + texto.value.length;
        desabilitar.disabled = true;
    } else {
        document.getElementById(alerta_nombreEditar).innerHTML = "";
        desabilitar.disabled = false;
    }
}

function validarDescripcionCategoriaEditar(texto, campos_alerta, alerta_descripEdit, longitud) {
    var desabilitar = document.getElementById("envio");
    
    if (texto.value.length < longitud) {
        document.getElementById(alerta_descripEdit).innerHTML = campos_alerta + " debe tener mas de " + longitud + " caracteres. Actualmente cuenta con: " + texto.value.length;
        desabilitar.disabled = true;
    } else {
        document.getElementById(alerta_descripEdit).innerHTML = "";
        desabilitar.disabled = false;
    }
}


