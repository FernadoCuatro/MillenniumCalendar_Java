function validarFacilitadorNombre(texto, campos_alerta, alerta_nombre, longitud) {
    var desabilitar = document.getElementById("envio");
    
    if (texto.value.length < longitud) {
        document.getElementById(alerta_nombre).innerHTML = campos_alerta + " debe tener mas de " + longitud + " caracteres. Actualmente cuenta con: " + texto.value.length;
        desabilitar.disabled = true;
    } else {
        document.getElementById(alerta_nombre).innerHTML = "";
        desabilitar.disabled = false;
    }
}

function validarFacilitadorEstudio(texto, campos_alerta, alerta_estudio, longitud) {
    var desabilitar = document.getElementById("envio");
    
    if (texto.value.length < longitud) {
        document.getElementById(alerta_estudio).innerHTML = campos_alerta + " debe tener mas de " + longitud + " caracteres. Actualmente cuenta con: " + texto.value.length;
        desabilitar.disabled = true;
    } else {
        document.getElementById(alerta_estudio).innerHTML = "";
        desabilitar.disabled = false;
    }
}

function validarFacilitadorNombreEditar(texto, campos_alerta, alerta_nombreEditar, longitud) {
    var desabilitar = document.getElementById("envio");
    
    if (texto.value.length < longitud) {
        document.getElementById(alerta_nombreEditar).innerHTML = campos_alerta + " debe tener mas de " + longitud + " caracteres. Actualmente cuenta con: " + texto.value.length;
        desabilitar.disabled = true;
    } else {
        document.getElementById(alerta_nombreEditar).innerHTML = "";
        desabilitar.disabled = false;
    }
}

function validarFacilitadorEstudioEditar(texto, campos_alerta, alerta_estudioEditar, longitud) {
    var desabilitar = document.getElementById("envio");
    
    if (texto.value.length < longitud) {
        document.getElementById(alerta_estudioEditar).innerHTML = campos_alerta + " debe tener mas de " + longitud + " caracteres. Actualmente cuenta con: " + texto.value.length;
        desabilitar.disabled = true;
    } else {
        document.getElementById(alerta_estudioEditar).innerHTML = "";
        desabilitar.disabled = false;
    }
}